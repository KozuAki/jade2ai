
filename<-dir(path=wdin1,
              pattern=filename1,
              full.names = T)
cat("読み込んだファイル名：",filename, "\n")
system.df<-read.csv(filename,skip=1,header=T)

#head(system.df)
# SIJYO_C SEQNO MIZUAGE_D GYOKYO_C KUMIAIIN_C GYOKIND_C GYOSYU_C MEIGARA1_C MEIGARA2_C BISUU JURYOU GOUKEI   TIMESTAMP MIZUAGE
# 1 24711000 10790  19881205 24810700          0      1099     1630          0          0      0     40      0 1.98812e+11       0
# 2 24711000 10791  19881210 24810700          0      1099     1630          0          0      0     30      0 1.98812e+11       0

 


#変換table読み込み=========
tablenames<-dir(path="./元データ/水産情報システム元データ（CSV)/code.table",
                pattern="code.table",
                full.name=T)

table.list<-NULL
for(i in 1:length(tablenames)){
  table.i<-read.table(tablenames[i],header=T,skip=0,sep=",")　　#重すぎる
  table.list<-c(table.list,list(table.i))
}
rm(table.i)

table_kumiaiin<-read.csv(paste0("./元データ/水産情報システム元データ（CSV)/code.table",
                                "/table_kumiaiin.csv"),
                         skip=1,header=T)
table.list$kumiaiin<-table_kumiaiin[,c(2,3,4,7,11)]
rm(table_kumiaiin)

names(table.list)<-c("gyokind","gyokyo","gyosyu","sijyo","kumiaiin")
#summary(table.list)
#str(table.list)
# ========



#項目を選択し、項目名を変更=======
koumoku<-c("SIJYO_C",
           "MIZUAGE_D",
           "GYOKYO_C",
           "KUMIAIIN_C",
           "GYOKIND_C",
           "GYOSYU_C",
           "MEIGARA1_C",
           "MEIGARA2_C",
           "JURYOU",
           "GOUKEI") #"KINGAKU")
system.df<-system.df[,koumoku]
koumoku1<-c("sijyo",
            "date",
            "gyokyo",
            "kumiaiin",
            "gyokind",
            "gyosyu",
            "meigara1",
            "meigara2",
            "catch",
            "kingaku")#"kingaku")
colnames(system.df)<-koumoku1
system.df[1:2,]
rm(koumoku,koumoku1)
#=========


#年月日の作成========
system.df$year<-as.numeric(substr(system.df[,"date"],1,4))
system.df$month<-as.numeric(substr(system.df[,"date"],5,6))
system.df$day<-as.numeric(substr(system.df[,"date"],7,8))

system.df$date<-as.Date(as.character(system.df$date),"%Y%m%d")  
# ========




#条件を絞る　=========

#大型定置のみ  搬入品6001、卸売販売7001も除かれる
#cond1<-system.df$gyokind=="1001"
#system.df1<-system.df[cond1,]

#市場を絞る
sijyo.v<-c(24749000,        #      氷見
           24738000,  #        新湊　
           24737000,  #               四方
           24726000,  #               岩瀬
           24725000,  #               水橋
           24724000,  #             滑川　
           24723001,  #               経田
           24723000,  #             魚津　
           24711000,  #             黒部　
           24712000,  #             宮崎浦
           24799800,  #       富山不明市場
           24799900,  #     富山その他市場
           24760100 )
#24749010       氷見市場七尾分
#25791010             七尾公設
#25791020               能都町

#漁協を絞る
gyokyo.v<-c(24890100,24890000,
            24849005,24849004,24849003,24849002,24849001,24849000,24838200,
            24838000,24837400,24837200,
            24837000,24826000,24825000,
            24824000,
            24823002,24823001,24823000,
            24821100,
            24811000,
            24810700,
            24810600,
            24810500,
            24810400,
            24810300,
            24810200,
            24810100 )
#新潟市振　23899900 新潟親不知23821202　新潟糸魚川　23821100
#その他県外、24893000 25891100 25891200 25891300 25891400

#漁法で絞る
# cond3<-system.df$gyokind!=6001
# cond3<-cond3 & system.df$gyokind!=7001

system.df<-system.df[system.df$sijyo%in%sijyo.v 
                     &system.df$gyokyo%in%gyokyo.v
                     &system.df$gyokind!=6001 &system.df$gyokind!=7001 ,]

sum(system.df$catch)

summary(system.df)
gc(T,T)

